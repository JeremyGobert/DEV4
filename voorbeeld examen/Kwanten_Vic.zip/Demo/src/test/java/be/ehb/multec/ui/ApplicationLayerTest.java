package be.ehb.multec.ui;

import org.junit.jupiter.api.Test;

class ApplicationLayerTest {
 
}