package be.ehb.multec.data;

import static org.junit.jupiter.api.Assertions.*;

/* public class RepositoriesTester {
    private static final AuteurRepository AUTEUR_REPO = new InMemoryAuteurRepository();

    private RepositoriesTester() { }

    public static AuteurRepository getAuteurRepository() { return AUTEUR_REPO; }
} */