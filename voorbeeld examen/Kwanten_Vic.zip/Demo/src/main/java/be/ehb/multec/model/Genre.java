package be.ehb.multec.model;

public enum Genre {
    THRILLER, KINDERBOEK, ROMAN, DETECTIVE
}
