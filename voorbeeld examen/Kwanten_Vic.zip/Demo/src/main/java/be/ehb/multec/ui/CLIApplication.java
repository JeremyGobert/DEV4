package be.ehb.multec.ui;

import be.ehb.multec.data.Repositories;
import be.ehb.multec.model.*;
import be.ehb.multec.data.util.*;
import java.time.LocalDate;

import java.util.List;

import static be.ehb.multec.data.Repositories.getAuteurRepository;
import static be.ehb.multec.data.Repositories.getBoekRepository;

public class CLIApplication {
    public static void main(String[] args) {
        //System.out.println("---        auteur WITH id         ---");
        //System.out.println(getAuteurRepository().getauteur(2));
        //MySqlConnection.resetDatabase();

        //System.out.println("---        boek WITH id         ---");
        //System.out.println(getBoekRepository().getboek(2));
        //MySqlConnection.resetDatabase();

        //System.out.println("---     Search auteur      ---");
        //List<auteur> auteurs=getAuteurRepository().getauteurs("kwan", false);
        //System.out.println(auteurs);

        //System.out.println("---     Remove auteur      ---");
        //getAuteurRepository().removeauteur(new auteur(4, "N/A", "N/A", null));

        //System.out.println("---     Remove boek      ---");
        //getBoekRepository().removeboek(new boek(2, "N/A", 0, 0, 0, 0, Genre.THRILLER));

        //System.out.println("---           ADD auteur           ---");
        //auteur auteur = new auteur( "moeder", "vader", LocalDate.of(2005, 5, 4));
        //getAuteurRepository().addauteur(auteur);
        //System.out.println(getAuteurRepository().getauteur(4));
        //System.out.println(auteur);

        //System.out.println("---           ADD boek           ---");
        //boek boek = new boek("moeder", 54, 154, 3, 1, Genre.ROMAN);
        //getBoekRepository().addboek(boek);
        //System.out.println(getBoekRepository().getboek(5));
        //System.out.println(boek);


   

    }
}
